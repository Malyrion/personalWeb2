import React from 'react'

import "../css/Navigation.css"

function SNavigation() {
  return (
  <div>  <ul>
        <li><img src="" alt="" /> Image Logo</li>
        <li><a href="">About</a></li>
        <li><a href="">Experience</a></li>
        <li><a href="">Projects</a></li>
        <li><button type="button">Lets talk</button> </li>

    </ul></div>
  )
}

export default SNavigation
